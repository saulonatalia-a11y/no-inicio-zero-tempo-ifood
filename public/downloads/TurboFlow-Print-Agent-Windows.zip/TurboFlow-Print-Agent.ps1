﻿param(
  [int]$Port = 17891
)

$ErrorActionPreference = "Stop"
$prefix = "http://127.0.0.1:$Port/"

function Write-JsonResponse {
    param($Response, [int]$StatusCode, $Object)
    $json = $Object | ConvertTo-Json -Depth 10 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $Response.StatusCode = $StatusCode
    $Response.ContentType = "application/json; charset=utf-8"
    $Response.Headers.Add("Access-Control-Allow-Origin","*")
    $Response.Headers.Add("Access-Control-Allow-Headers","Content-Type")
    $Response.Headers.Add("Access-Control-Allow-Methods","GET,POST,OPTIONS")
    $Response.ContentLength64 = $bytes.Length
    $Response.OutputStream.Write($bytes,0,$bytes.Length)
    $Response.OutputStream.Close()
}

function Get-InstalledPrinters {
    try {
        return @(Get-Printer | Select-Object -ExpandProperty Name)
    } catch {
        return @()
    }
}

function Print-RawText {
    param([string]$PrinterName, [string]$Text)

    # Uses the Windows print subsystem through a temporary text file.
    # For many generic/thermal drivers this prints directly without browser popup.
    $tmp = Join-Path $env:TEMP ("turboflow_" + [Guid]::NewGuid().ToString() + ".txt")
    [System.IO.File]::WriteAllText($tmp, $Text, [System.Text.Encoding]::UTF8)
    try {
        Get-Content -Raw -Encoding UTF8 $tmp | Out-Printer -Name $PrinterName
    } finally {
        Remove-Item $tmp -ErrorAction SilentlyContinue
    }
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)

try {
    $listener.Start()
} catch {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show(
        "Não foi possível abrir o TurboFlow Print Agent na porta $Port.`n`n$($_.Exception.Message)",
        "TurboFlow Print Agent"
    ) | Out-Null
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Yellow
Write-Host " TurboFlow Print Agent" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Yellow
Write-Host "Status: ABERTO" -ForegroundColor Green
Write-Host "Endereço local: $prefix"
Write-Host "Pode minimizar esta janela. Não feche enquanto estiver usando impressão automática."
Write-Host ""

while ($listener.IsListening) {
    try {
        $ctx = $listener.GetContext()
        $req = $ctx.Request
        $res = $ctx.Response

        if ($req.HttpMethod -eq "OPTIONS") {
            Write-JsonResponse $res 200 @{ ok = $true }
            continue
        }

        if ($req.Url.AbsolutePath -eq "/status" -and $req.HttpMethod -eq "GET") {
            Write-JsonResponse $res 200 @{
                ok = $true
                name = "TurboFlow Print Agent"
                version = "1.0.0"
                printers = Get-InstalledPrinters
            }
            continue
        }

        if ($req.Url.AbsolutePath -eq "/printers" -and $req.HttpMethod -eq "GET") {
            Write-JsonResponse $res 200 @{
                ok = $true
                printers = Get-InstalledPrinters
            }
            continue
        }

        if ($req.Url.AbsolutePath -eq "/print" -and $req.HttpMethod -eq "POST") {
            $reader = New-Object System.IO.StreamReader($req.InputStream, $req.ContentEncoding)
            $bodyText = $reader.ReadToEnd()
            $reader.Close()
            $body = $bodyText | ConvertFrom-Json

            $printer = [string]$body.printer
            $text = [string]$body.text

            if ([string]::IsNullOrWhiteSpace($printer)) {
                Write-JsonResponse $res 400 @{ ok = $false; error = "printer_required" }
                continue
            }
            if ([string]::IsNullOrWhiteSpace($text)) {
                Write-JsonResponse $res 400 @{ ok = $false; error = "text_required" }
                continue
            }

            $available = Get-InstalledPrinters
            if ($available -notcontains $printer) {
                Write-JsonResponse $res 404 @{ ok = $false; error = "printer_not_found"; printers = $available }
                continue
            }

            Print-RawText -PrinterName $printer -Text $text
            Write-JsonResponse $res 200 @{ ok = $true; printer = $printer }
            continue
        }

        Write-JsonResponse $res 404 @{ ok = $false; error = "not_found" }
    } catch {
        try {
            Write-JsonResponse $res 500 @{ ok = $false; error = $_.Exception.Message }
        } catch {}
    }
}
