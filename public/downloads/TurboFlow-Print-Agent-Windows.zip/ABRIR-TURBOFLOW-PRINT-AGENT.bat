@echo off
title TurboFlow Print Agent
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0TurboFlow-Print-Agent.ps1"
pause
