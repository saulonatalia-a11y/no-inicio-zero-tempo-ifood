@echo off
title Instalar TurboFlow Print Agent
set "TARGET=%LOCALAPPDATA%\TurboFlowPrintAgent"
if not exist "%TARGET%" mkdir "%TARGET%"
copy /Y "%~dp0TurboFlow-Print-Agent.ps1" "%TARGET%\TurboFlow-Print-Agent.ps1" >nul
copy /Y "%~dp0ABRIR-TURBOFLOW-PRINT-AGENT.bat" "%TARGET%\ABRIR-TURBOFLOW-PRINT-AGENT.bat" >nul

set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
copy /Y "%TARGET%\ABRIR-TURBOFLOW-PRINT-AGENT.bat" "%STARTUP%\TurboFlow Print Agent.bat" >nul

echo.
echo TurboFlow Print Agent instalado.
echo Ele sera iniciado automaticamente junto com o Windows.
echo.
start "" "%TARGET%\ABRIR-TURBOFLOW-PRINT-AGENT.bat"
pause
